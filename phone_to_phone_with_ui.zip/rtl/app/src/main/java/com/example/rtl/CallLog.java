package com.example.rtl;

public class CallLog {
    private long id;
    private String startTime;
    private String endTime;
}
