package com.example.rtl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class MainActivity2 extends AppCompatActivity {


    private Button homeback;

    private CallLogDbHelper dbHelper;
    private SQLiteDatabase db;

    private TextView callLogTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        dbHelper = new CallLogDbHelper(this);
        db = dbHelper.getReadableDatabase();

        callLogTextView = findViewById(R.id.callLogTextView);

        displayCallLogs();
        homeback = findViewById(R.id.homebutton);

        homeback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                // start the activity connect to the specified class
                startActivity(intent);
            }

        });
    }


//    private void displayCallLogs() {
//        List<CallLogDbHelper.CallLog> callLogs = dbHelper.getAllCallLogs();
//        StringBuilder callLogText = new StringBuilder();
//
//        for (CallLogDbHelper.CallLog callLog : callLogs) {
//            callLogText.append("ID: ").append(callLog.getId()).append("\n");
//            callLogText.append("Start Time: ").append(callLog.getStartTime()).append("\n");
//            callLogText.append("End Time: ").append(callLog.getEndTime()).append("\n\n");
//        }
//
//        callLogTextView.setText(callLogText.toString());
//    }
//private void displayCallLogs() {
//    List<CallLogDbHelper.CallLog> callLogs = dbHelper.getAllCallLogs();
//    StringBuilder callLogText = new StringBuilder();
//
//    for (int i = callLogs.size() - 1; i >= 0; i--) {
//        CallLogDbHelper.CallLog callLog = callLogs.get(i);
//        callLogText.append("ID: ").append(callLog.getId()).append("\n\n");
//        callLogText.append("Start Time :   ").append(callLog.getStartTime()).append("\n");
//        callLogText.append("End Time   :   ").append(callLog.getEndTime()).append("\n\n\n");
//    }
//
//    callLogTextView.setText(callLogText.toString());
//}

    private void displayCallLogs() {
        List<CallLogDbHelper.CallLog> callLogs = dbHelper.getAllCallLogs();
        StringBuilder callLogText = new StringBuilder();

        for (int i = callLogs.size() - 1; i >= 0; i--) {
            CallLogDbHelper.CallLog callLog = callLogs.get(i);
            callLogText.append("ID: ").append(callLog.getId()).append("\n\n");
            callLogText.append("Start Time :   ").append(callLog.getStartTime()).append("\n");

            // Check if End Time is null
            if (callLog.getEndTime() == null) {
                callLogText.append("End Time   :   Call Not Connected").append("\n\n\n");
            } else {
                callLogText.append("End Time   :   ").append(callLog.getEndTime()).append("\n\n\n");
            }
        }

        callLogTextView.setText(callLogText.toString());
    }


}