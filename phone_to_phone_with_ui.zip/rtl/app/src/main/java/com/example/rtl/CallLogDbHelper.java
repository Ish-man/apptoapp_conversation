package com.example.rtl;
import android.annotation.SuppressLint;
import android.database.Cursor;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class CallLogDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "CallLog.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_CALL_LOG = "call_log";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_START_TIME = "start_time";
    public static final String COLUMN_END_TIME = "end_time";

    @SuppressLint("Range")
    public List<CallLog> getAllCallLogs() {
        List<CallLog> callLogs = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_CALL_LOG,
                null,
                null,
                null,
                null,
                null,
                null
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                CallLog callLog = new CallLog();
                callLog.setId(cursor.getLong(cursor.getColumnIndex(COLUMN_ID)));
                callLog.setStartTime(cursor.getString(cursor.getColumnIndex(COLUMN_START_TIME)));
                callLog.setEndTime(cursor.getString(cursor.getColumnIndex(COLUMN_END_TIME)));

                callLogs.add(callLog);
            } while (cursor.moveToNext());

            cursor.close();
        }

        return callLogs;
    }

    public class CallLog {
        private long id;
        private String startTime;
        private String endTime;

        public CallLog() {
            // Default constructor
        }

        public CallLog(long id, String startTime, String endTime) {
            this.id = id;
            this.startTime = startTime;
            this.endTime = endTime;
        }

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public String getStartTime() {
            return startTime;
        }

        public void setStartTime(String startTime) {
            this.startTime = startTime;
        }

        public String getEndTime() {
            return endTime;
        }

        public void setEndTime(String endTime) {
            this.endTime = endTime;
        }
    }
    private static final String CREATE_TABLE_CALL_LOG =
            "CREATE TABLE " + TABLE_CALL_LOG + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_START_TIME + " TEXT," +
                    COLUMN_END_TIME + " TEXT);";

    public CallLogDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_CALL_LOG);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Implement if needed when upgrading database version
    }




}
