    package com.example.rtl;

    import android.content.ContentValues;
    import android.database.Cursor;
    import android.database.sqlite.SQLiteDatabase;

    import java.text.SimpleDateFormat;
    import java.util.Date;
    import java.util.Locale;



    import android.Manifest;
    import android.annotation.SuppressLint;
    import android.content.Intent;
    import android.content.pm.PackageManager;
    import android.graphics.Color;
    import android.media.AudioFormat;
    import android.media.AudioManager;
    import android.media.AudioRecord;
    import android.media.AudioTrack;
    import android.media.MediaRecorder;
    import android.os.Build;
    import android.os.Bundle;
    import android.os.Environment;
    import android.os.Handler;
    import android.view.Menu;
    import android.view.MenuInflater;
    import android.view.MenuItem;
    import android.view.MotionEvent;
    import android.view.View;
    import android.widget.Button;
    import android.widget.EditText;
    import android.widget.ImageView;
    import android.widget.ProgressBar;
    import android.widget.TextView;
    import android.widget.Toast;

    import android.app.AlertDialog;
    import android.content.DialogInterface;


    import androidx.annotation.NonNull;
    import androidx.annotation.RequiresApi;
    import androidx.appcompat.app.AppCompatActivity;
    import androidx.core.app.ActivityCompat;
    import androidx.core.content.ContextCompat;

    import android.media.MediaPlayer;



    import java.io.IOException;
    import java.io.InputStream;
    import java.io.OutputStream;
    import java.net.InetSocketAddress;
    import java.net.Socket;
    import java.nio.charset.StandardCharsets;
    import java.text.SimpleDateFormat;
    import java.util.Date;
    import java.util.Locale;

    import android.util.Log;

    import pl.droidsonroids.gif.GifImageView;


    public class MainActivity extends AppCompatActivity {

        MediaRecorder mediaRecorder = new MediaRecorder();

        private boolean isBeepSoundPlayed = false;
        private AudioTrack audioTrack;
        //creating object of mediaPlayer
        public MediaPlayer mediaPlayer;
        private Socket socket;
        private OutputStream outputStream;
        private CallLogDbHelper dbHelper;
        private SQLiteDatabase db;

        public   boolean  flag =  false ;
    //    private Socket socketforsignals;
    //
    //    private Socket outputstreamforSignals;
        private static final int RECORD_AUDIO_PERMISSION_CODE = 1;
        private static final int INTERNET_PERMISSION_CODE = 1;

        private EditText ipAddressEditText; // EditText for IP address
        private Button audioStreamButton; // Button for audio streaming
        private Button connectbutton; // Button for audio streaming
        private Button  closeConnectionButton; // Button for audio streaming
        private ProgressBar progressBar; // Progress bar for connection

        private boolean isRecording = false;
    //    private MediaRecorder mediaRecorder;
        private GifImageView micon ;
        private GifImageView micoff ;
        private TextView textView1 ;

        private ImageView recstart;
        private ImageView recstop;
        private boolean isSending = false;

        private Button buttonrecord ;
        private Button logbtn;
        private  boolean ok ;

        @SuppressLint({"ClickableViewAccessibility", "CutPasteId"})
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            ok  =  false ;

            micon = findViewById(R.id.micon);
            micoff = findViewById(R.id.micoff);
            recstart = findViewById(R.id.startrecc );
            recstop = findViewById(R.id.stoprecc);
            recstop.setVisibility(View.GONE);
            recstart.setVisibility(View.GONE);
            micon.setVisibility(View.GONE);

            recstart.setVisibility(View.VISIBLE);
            recstop.setVisibility(View.GONE);
    //        recstart.setEnabled(false);

            dbHelper = new CallLogDbHelper(this);
            db = dbHelper.getWritableDatabase();


            TextView messageTextView = findViewById(R.id.textViewMessage);
            textView1 = findViewById(R.id.textView);

            // Initialize the Button for audio streaming
            audioStreamButton = findViewById(R.id.buttonAudioStream);
            audioStreamButton.setEnabled(false); // Initially disabled
            audioStreamButton.setBackgroundColor(Color.GRAY); // Initially disabled

            connectbutton = findViewById(R.id.buttonConnect);
            connectbutton.setEnabled(true); // Initially enabled
            connectbutton.setTextColor(Color.BLACK);
            connectbutton.setBackgroundColor(Color.GREEN); // Initially disabled
    //        gifrec.setVisibility(View.GONE);

            // Initialize the Progress bar for connection
            progressBar = findViewById(R.id.progressBar);
            progressBar.setVisibility(View.GONE);

            logbtn = findViewById(R.id.logs);

            // Check and request necessary permissions
            checkAndRequestPermissions();

            buttonrecord = findViewById(R.id.buttonRecordAudio);
            buttonrecord.setEnabled(false);
            buttonrecord.setAlpha(0);
            buttonrecord.setOnClickListener(new View.OnClickListener() {
                @SuppressLint("NewApi")
                @Override
                public void onClick(View v) {
                    // Start or stop recording audio based on the current state
                    if (!isRecording) {
                        startRecordingAudio();
                    } else {
                        stopRecordingAudio();
                    }
                }
            });

            logbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    // start the activity connect to the specified class
                    startActivity(intent);
                }
            });


            closeConnectionButton = findViewById(R.id.buttonCloseConnection);
            closeConnectionButton.setEnabled(false);
            closeConnectionButton.setBackgroundColor(Color.GRAY);
            closeConnectionButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    stopRecordingAudio();
                    closeSocketConnection();
                    updateEndTime();
//                    playdisconnect();
                }
            });



            connectbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    connectToServer();
                    // Insert start time into the database
                    insertStartTime();
                }
            });




            // Set up touch listener to stop audio streaming
            audioStreamButton.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent event) {
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        isSending = true;
                        try {
    //                        gifrec.setVisibility(View.GONE);
                            micon.setScaleX(1.3f);
                            micon.setScaleY(1.3f);


                            sendHighSignal();
                        sendTextMessage("Sound");
                        } catch (IOException e) {
    //                        throw new RuntimeException(e);
                        }
                    }  ;
                    if(event.getAction() == MotionEvent.ACTION_UP) {
                        isSending = false;
                        try {
                            micon.setScaleX(1.0f);
                            micon.setScaleY(1.0f);
                            sendLowSignal();
                            sendTextMessage("5");
                        } catch (IOException e) {
    //                        throw new RuntimeException(e);
                        }
    //                    gifrec.setVisibility(View.VISIBLE);

                        stopAudioStreaming();
                        try {
//                            startDataReceiving();
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }
                    return false;
                }

                private void stopAudioStreaming() {
                }
            });
        }


        @RequiresApi(api = Build.VERSION_CODES.S)
        private void startRecordingAudio() {
            // Initialize MediaRecorder
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            buttonrecord.setBackgroundColor(Color.RED);
            buttonrecord.setText("STOP RECORDING");
    //        recstart.setVisibility(View.GONE);
            recstop.setVisibility(View.VISIBLE);
            recstart.setVisibility(View.GONE);

            // Set output file path to the download folder with filename based on current date and time
            String timeStamp = new SimpleDateFormat("dd_MM_yyyy   hh_mm_ss a", Locale.getDefault()).format(new Date());
            String fileName = "motorola" + timeStamp + ".mp3";
            String outputFile = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/" + fileName;
            mediaRecorder.setOutputFile(outputFile);

            try {
                mediaRecorder.prepare();
                mediaRecorder.start();
                isRecording = true;
                Toast.makeText(MainActivity.this, "Recording started", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }


        private String getCurrentTime() {
            long currentTimeMillis = System.currentTimeMillis();
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy  hh:mm:ss a", Locale.getDefault());
            Date currentDate = new Date(currentTimeMillis);
            return sdf.format(currentDate);
        }

        private void insertStartTime() {
            ContentValues values = new ContentValues();
            values.put(CallLogDbHelper.COLUMN_START_TIME, getCurrentTime()); // Implement getCurrentTime() accordingly
            db.insert(CallLogDbHelper.TABLE_CALL_LOG, null, values);
        }



        private void updateEndTime() {
            ContentValues values = new ContentValues();
            values.put(CallLogDbHelper.COLUMN_END_TIME, getCurrentTime());

            String orderBy = CallLogDbHelper.COLUMN_ID + " DESC";
            String limit = "1";

            Cursor cursor = db.query(
                    CallLogDbHelper.TABLE_CALL_LOG,
                    null,
                    null,
                    null,
                    null,
                    null,
                    orderBy,
                    limit
            );

            if (cursor != null && ((Cursor) cursor).moveToFirst()) {
                // Get the ID of the latest row
                @SuppressLint("Range") int latestId = cursor.getInt(cursor.getColumnIndex(CallLogDbHelper.COLUMN_ID));

                // Update the latest row
                String whereClause = CallLogDbHelper.COLUMN_ID + "=?";
                String[] whereArgs = {String.valueOf(latestId)};
                db.update(CallLogDbHelper.TABLE_CALL_LOG, values, whereClause, whereArgs);

                cursor.close();
            }
        }


        private void stopRecordingAudio() {
            if (isRecording) {
                mediaRecorder.stop();
                mediaRecorder.release();
                mediaRecorder = null;
                isRecording = false;
                Toast.makeText(MainActivity.this, "Recording stopped", Toast.LENGTH_SHORT).show();
                buttonrecord.setBackgroundColor(Color.BLUE);
                buttonrecord.setText("START RECORDING");
                recstart.setVisibility(View.VISIBLE);
                recstop.setVisibility(View.GONE);

            }
        }

        private void checkAndRequestPermissions() {
            String[] permissions = {
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.INTERNET
            };

            boolean allPermissionsGranted = true;

            for (String permission : permissions) {
                if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }

            if (allPermissionsGranted) {
    //            showMessage("Permissions granted!");
            } else {
                ActivityCompat.requestPermissions(this, permissions, RECORD_AUDIO_PERMISSION_CODE);
                ActivityCompat.requestPermissions(this, permissions, INTERNET_PERMISSION_CODE);

            }
        }

        private void startAudioStreaming() {
            // Check if the socket is null or not connected
            if (socket == null || !socket.isConnected()) {
    //            showMessage("Socket not connected.");
                return;
            }

        }


        private void playBeepSound() {

            if (mediaPlayer == null) {
                mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.jarvis_connected); // Replace with your beep sound resource
            }

            if (!mediaPlayer.isPlaying() && !isBeepSoundPlayed) {
                mediaPlayer.start();
                isBeepSoundPlayed = true; // Set the flag to indicate that the sound has been played
                mediaPlayer = null ;
            }
        }
        private void playdisconnect() {
            mediaPlayer= null ;
            if (mediaPlayer == null) {
                mediaPlayer = MediaPlayer.create(MainActivity.this, R.raw.disco); // Replace with your beep sound resource
            }

            if (!mediaPlayer.isPlaying() && !isBeepSoundPlayed) {
                mediaPlayer.start();
                mediaPlayer = null ;
            }
        }
        public void connectToServer() {
            audioStreamButton.setEnabled(true); // Enable audio streaming button


            flag =  false ;

            connectbutton.setEnabled(false);
            connectbutton.setBackgroundColor(Color.GRAY);

            audioStreamButton.setEnabled(true); // Enable audio streaming button
            audioStreamButton.setBackgroundColor(Color.GREEN); // Enable audio streaming button
            closeConnectionButton.setEnabled(true);
            //                                              gifrec.setVisibility(View.VISIBLE);
            closeConnectionButton.setBackgroundColor(Color.RED);
            micon.setVisibility(View.VISIBLE);
            micoff.setVisibility(View.GONE);
            buttonrecord.setEnabled(true);
            connectbutton.setText("CONNECTED");
            logbtn.setEnabled(false);

            final String ipAddress = "1.tcp.in.ngrok.io";
            final int port = 20434;  // Use the same port number as in your Python server code
            progressBar.setVisibility(View.GONE); // Show progress bar

            // Create a socket and connect to the server on a background thread
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        socket = new Socket();
                        socket.connect(new InetSocketAddress(ipAddress,  port));
                        outputStream = socket.getOutputStream();
                        startDataReceiving(); // Start receiving data immediately

//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    textView1.setText("CHANNEL BUSY");
//                                    // Clear the text after 2 seconds
//                                    new Handler().postDelayed(new Runnable() {
//                                        @Override
//                                        public void run() {
//                                            textView1.setText("");
//                                        }
//                                    }, 2000);
//                                }
//                            });

                    } catch (IOException e) {
                        e.printStackTrace();
    //                    textView1.setText("SERVER NOT RUNNING");
                        // Connection failed, show a toast message on the UI thread
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                progressBar.setVisibility(View.GONE);
                                textView1.setText("SERVER NOT RUNNING");
    //                            showMessage("Failed to connect to the server.");
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        textView1.setText("");
                                    }
                                }, 2000);
                            }
                        });
                    }
                }
            }).start();
        }


        private void closeSocketConnection() {
            if (socket != null && socket.isConnected()) {
                try {
                    socket.close();
    //                showMessage("Socket connection closed.");
                    closeConnectionButton.setEnabled(false);
                    audioStreamButton.setEnabled(false);
                    audioStreamButton.setBackgroundColor(Color.GRAY);
                    connectbutton.setEnabled(true);
                    closeConnectionButton.setBackgroundColor(Color.GRAY);
                    connectbutton.setBackgroundColor(Color.GREEN);
                    textView1.setText("");
                    micon.setVisibility(View.GONE);
                    micoff.setVisibility(View.VISIBLE);
                    connectbutton.setText("          CONNECT TO SERVER");
                    buttonrecord.setEnabled(false);
                    logbtn.setEnabled(true);
                    isBeepSoundPlayed=false;
                    recstop.setVisibility(View.GONE);
    //                recstart.setVisibility(View.GONE);


    //                gifrec.setVisibility(View.GONE);



                } catch (IOException e) {
                    e.printStackTrace();
    //                showMessage("Error closing socket connection: " + e.toString());
                }
            } else {
    //            showMessage("Socket not connected.");
            }
        }


        //this method is actually used to send audio to the python server
        private void sendTextMessage(final String message) throws IOException {
            if (socket == null || !socket.isConnected()) {
    //            showMessage("Socket not connected.");
                return;
            }

            int sampleRate = 44100;
            int audioSource = MediaRecorder.AudioSource.MIC;
            int channelConfig = AudioFormat.CHANNEL_IN_MONO;
            int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
            int bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat);
    //        int bufferSize = 4096;

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            AudioRecord audioRecord = new AudioRecord(audioSource, sampleRate, channelConfig, audioFormat, bufferSize);

            audioRecord.startRecording();

            byte[] audioBuffer = new byte[bufferSize];

            // Send the text message to the server in a background thread
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        byte[] messageBytes = message.getBytes(StandardCharsets.UTF_8);
                        outputStream = socket.getOutputStream();

                        while (isSending) {
                            textView1.setText("TRANSMITTING");


                            int bytesRead = audioRecord.read(audioBuffer, 0, bufferSize);
                            if (bytesRead > 0) {
                                boolean isZeroData = true;
                                for (int i =0; i<bytesRead; i++){
                                    if (audioBuffer[i] != 0){
                                        isZeroData = false;
                                        break;
                                    }
                                }
                                if (!isZeroData) {
                                    // Send audio data
                                    outputStream.write(audioBuffer, 0, bytesRead);
                                }
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
    //                    showMessage(e.toString());
                    } finally {
                        audioRecord.stop();
                        audioRecord.release();
                    }
                }
            }).start();
        }

        //sending signals for controlling relay
        private void sendHighSignal() {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (socket != null && socket.isConnected()) {
                            OutputStream outputStream = socket.getOutputStream();
                            outputStream.flush();
                            outputStream.write("high\n".getBytes(StandardCharsets.UTF_8));
                            outputStream.flush(); // Flush to send immediately
    //                        showMessage("High signal sent.");
                        } else {
    //                        showMessage("Socket not connected.");
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
    //                    showMessage("Error sending high signal: " + e.toString());
                    }
                }
            }).start();
        }

        private void sendLowSignal() {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (socket != null && socket.isConnected()) {
                            OutputStream outputStream = socket.getOutputStream();
                            outputStream.flush();
                            outputStream.write("\nlow\n".getBytes(StandardCharsets.UTF_8));
                            outputStream.flush(); // Flush to send immediately
    //                        showMessage("Low signal sent.");
                        } else {
    //                        showMessage("Socket not connected.");
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
    //                    showMessage("Error sending low signal: " + e.toString());
                    }
                }
            }).start();
        }



        private boolean checkBytesReceived() {
            try {
                InputStream inputStream = socket.getInputStream();
                byte[] buffer = new byte[1024];
                int bytesRead = inputStream.read(buffer);
                return bytesRead > 0;
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }


        public boolean hasMeaningfulAudio(byte[] audioData, int bytesRead) {
            // Calculate the average amplitude of the audio data
            double sum = 0;
            for (int i = 0; i < bytesRead; i += 2) {
                short sample = (short)((audioData[i] & 0xFF) | (audioData[i + 1] << 8));
                sum += Math.abs(sample);
            }
            double averageAmplitude = sum / (bytesRead / 2);

            // You can adjust this threshold value according to your application's requirements
            double threshold = 1000; // Example threshold value

            // Return true if the average amplitude exceeds the threshold, indicating meaningful audio
            return averageAmplitude > threshold;
        }
        //thread to receive audio and playing the audio from python server
        private void startDataReceiving() {
            // Check if the socket is null or not connected
//            if (socket == null || !socket.isConnected()) {
//    //            showMessage("Socket not connected.");
//                return;
//            }


            int sampleRate = 44100;
            int channelConfig = AudioFormat.CHANNEL_OUT_MONO;
            int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
            int bufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat);
            audioTrack = new AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    bufferSize,
                    AudioTrack.MODE_STREAM
            );
            audioTrack.play();


            // Create a new thread for receiving data
            Thread receiveThread = new Thread(() -> {
                try {

                    // Set up input stream to receive data
    //                InputStream inputStream = socket.getInputStream();
                    byte[] buffer = new byte[1024];
    //                recstart.setVisibility(View.VISIBLE);
    //                int showonce = 0;
                    while (true) {
    //                    textView1.setText("RECEIVING");


                        InputStream inputStream = socket.getInputStream();
                        int bytesRead = inputStream.read(buffer);
    //                    Log.d("data", String.valueOf(bytesRead));

                        if (true) {


                            runOnUiThread(new Runnable() {
                                              @Override
                                              public void run() {
                                                  progressBar.setVisibility(View.GONE);

    //                            showMessage("Connected to the server!");
//                                                  connectbutton.setEnabled(false);
    //                            showMessage("button diBKED!");
//                                                  connectbutton.setBackgroundColor(Color.GRAY);
//
//                                                  audioStreamButton.setEnabled(true); // Enable audio streaming button
//                                                  audioStreamButton.setBackgroundColor(Color.GREEN); // Enable audio streaming button
//                                                  closeConnectionButton.setEnabled(true);
//    //                                              gifrec.setVisibility(View.VISIBLE);
//                                                  closeConnectionButton.setBackgroundColor(Color.RED);
//                                                  micon.setVisibility(View.VISIBLE);
//                                                  micoff.setVisibility(View.GONE);
//                                                  buttonrecord.setEnabled(true);
//                                                  connectbutton.setText("CONNECTED");
//                                                  logbtn.setEnabled(false);
//                                                  playBeepSound();
    //                                              recstart.setVisibility(View.VISIBLE);
    //                                              textView1.setText("RECEIVING");
                                                  ok =  false ;
                                                  flag =  true ;

                                                  if (hasMeaningfulAudio(buffer, bytesRead)) {
                                                      textView1.setText("");
    //                                                  runOnUiThread(() -> gifrec.setVisibility(View.VISIBLE)); // Show gif if meaningful audio
                                                  } else {
    //                                                  runOnUiThread(() -> gifrec.setVisibility(View.GONE)); // Hide gif if noise
                                                      textView1.setText("");
                                                  }

    //                                              startDataReceiving(); // Start receiving data immediately
                                              }
                                          });


    //                                              audioTrack.write(buffer, 0, bytesRead);
                            }


    //                        String receivedData = new String(buffer, StandardCharsets.UTF_8);
                            // Log the received hexadecimal data
    //                        Log.d("ReceivedData", receivedData);
                            audioTrack.write(buffer, 0, bytesRead);

                        }



                     } catch (IOException e) {
                    e.printStackTrace();
    //                showMessage("Error receiving data: " + e.toString());
                }

            });

            receiveThread.start();
        }




            @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            if (requestCode == RECORD_AUDIO_PERMISSION_CODE) {
                boolean allPermissionsGranted = true;
                for (int grantResult : grantResults) {
                    if (grantResult != PackageManager.PERMISSION_GRANTED) {
                        allPermissionsGranted = false;
                        break;
                    }
                }
                if (allPermissionsGranted) {
    //                showMessage("Permissions granted!");
                } else {
    //                showMessage("Permissions denied. The app requires these permissions to work.");
                }
            }
        }

    }